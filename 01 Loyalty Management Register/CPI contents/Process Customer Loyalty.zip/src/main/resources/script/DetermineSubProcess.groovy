package au.net.api.loyalty
import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.gateway.ip.core.customdev.util.SoapHeader;
/* ************************************************************************
    Program     : DetermineSubProcess.groovy
    Create Date : Mar-17-2020
    Author      : Stephen Xue
    Parameters  :
        message --> message reference from framework;
        testFlag--> true for test mode; default for production code mode;
    Function    :
        1. Read 'Source System' Property from SOAP Header;
        2. The sub process is determined by /Request/RequestType field.
    The function is to parse the field and populate it into Header property
    TransactionType.
 *************************************************************************/
Message processData(Message message, def testFlag = null) {
    def body = message.getBody(java.lang.String) as String;
    //def body = message.getBody() as String;
    
    // Get Source System from SOAP Header
    def closure_GetElementValueFromSOAPHeader = {
        SoapHeader header, String elementName ->
            String elementValue = "";
            def childNodes = header.getElement().childNodes;
            for(int i=0;i<childNodes.getLength();i++){
                if(childNodes.item(i).getNodeName() == elementName){
                    elementValue = childNodes.item(i).getTextContent();
                    break;
                }
            }
            return elementValue;
    }
    // Read Element 'SourceSystem' from SOAP Header
    def soapHeaders = message.getSoapHeaders();
    if(soapHeaders.size() == 0){
        message.setHeader("CamelHttpResponseCode", 400);
        def text = "Specify a SourceSystem in the SOAP Header";
        message.setBody(ErrorResponse(text));
    }else{
        def sourceSystem = closure_GetElementValueFromSOAPHeader(soapHeaders.get(0),"SourceSystem");
        if(sourceSystem == ""){
            sourceSystem = closure_GetElementValueFromSOAPHeader(soapHeaders.get(0),"sourcesystem");
        }
        if(sourceSystem == ""){
            message.setHeader("CamelHttpResponseCode", 400);
            def text = "Specify a SourceSystem in the SOAP Header";
            message.setBody(ErrorResponse(text));
        }else{
            // Parse request type
            def messageLog = messageLogFactory.getMessageLog(message);
            def Request = new XmlSlurper().parseText(body);
            if(Request.RequestType && !Request.RequestType.toString().trim().isEmpty()){
                message.setHeader('TransactionType', Request.RequestType);
                message.setHeader("SourceSystem", sourceSystem);
                if(messageLog != null){
                    messageLog.setStringProperty("Logging", "Header property 'TransactionType' has been assigned.");
                    messageLog.addAttachmentAsString("Source System: " + sourceSystem,"Source System: " + sourceSystem, "text/plain");
                }
            }else{
                message.setHeader("CamelHttpResponseCode", 400);
                def text = "Specify a RequestType in the message.";
                message.setBody(ErrorResponse(text));
            }
        }
    }
    return message;
}

String ErrorResponse(String message){
    def engine = new groovy.text.XmlTemplateEngine();
    def text = '''
        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
           <soap:Body>
              <soap:Fault>
                 <faultcode>Bad Request</faultcode>
                 <faultstring>$error</faultstring>
              </soap:Fault>
           </soap:Body>
        </soap:Envelope>
        ''';
    def binding = [error : message];
    def template = engine.createTemplate(text).make(binding)
    return template.toString();
}
