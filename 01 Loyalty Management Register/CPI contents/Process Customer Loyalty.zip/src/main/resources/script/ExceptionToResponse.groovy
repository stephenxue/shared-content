package au.net.api.loyalty
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

/* ************************************************************************
    Program     : ExceptionToResponse.groovy
    Create Date : Mar-18-2020
    Author      : Stephen Xue
    Parameters  :
        message --> message reference from framework;
        testFlag--> true for test mode; default for production code mode;
    Function    :
        Catch the exception raised and populate the error message into
        message body.
 *************************************************************************/
Message processData(Message message, def testFlag = null) {
    def exceptionMsg = message.getProperty("CamelExceptionCaught")
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addAttachmentAsString("Exception Message",exceptionMsg.getMessage(),"text/plain")
    message.setHeader("CamelHttpResponseCode", 500);
    def text = '''<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
           <soap:Body>
              <soap:Fault>
                 <faultcode>Internal Server Error</faultcode>
                 <faultstring>There is an Internal Server Error occurring in SAP CPI. Please contact IT Department.</faultstring>
              </soap:Fault>
           </soap:Body>
        </soap:Envelope>''';
    message.setBody(new String(text));
    return message;
}
