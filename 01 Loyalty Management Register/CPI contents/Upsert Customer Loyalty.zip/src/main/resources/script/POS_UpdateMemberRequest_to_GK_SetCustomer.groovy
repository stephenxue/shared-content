package au.net.api.loyalty
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

/* ************************************************************************
    Program     : POS_UpdateMemberRequest_to_GK_SetCustomer.groovy
    Create Date : Mar-27-2020
    Author      : Stephen Xue
    Parameters  :
        message --> message reference from framework;
        testFlag--> true for test mode; default for production code mode;
    Function    :
        1. Parse request message coming from POS for Member update/register
        2. Convert it into SetCustomer message to GK
    Source: XML
    Target: XML
 *************************************************************************/

Message processData(Message message, def testFlag = null) {
    def targetRequest;
    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.setStringProperty("Logging", ValueMapping("F"));
        
    // Parse request type
    def body = message.getBody(java.lang.String) as String;
    //def body = message.getBody() as String;
    def sourceRequest = new XmlSlurper(false,false).parseText(body);

    messageLog.setStringProperty("Logging", "Start mapping step.");
    
    targetRequest = Mapping(sourceRequest,testFlag);
    messageLog.setStringProperty("Logging", "Finish mapping step.");


    message.setHeader("Content-Type","Application/xml");
    message.setBody(targetRequest);
    return message;
}

String Mapping(def payload,def testFlag = null){
    def xmlWriter = new StringWriter();
    def xmlMarkup = new MarkupBuilder(xmlWriter);

    xmlMarkup
            .'ns0:setCustomer'('xmlns:ns0': 'http://customer.ws.extension.management.valuephone.com'){
                sessionId("");
                customer{
                    identifier{
                        email(payload.EmailAddress);
                        customerId("cpi_test01");
                        iso3166_1_alpha2CountryCode("AU");
                    }
                    gender(ValueMapping(payload.Gender,testFlag));
                    firstName(payload.FirstName);
                    lastName(payload.LastName);
                    addressStreetName(payload.AddressLine2);
                    addressStreetNumber(payload.AddressLine1);
                    city(payload.Suburb);
                    postalCode(payload.PostCode);
                    birthday(FormatDate(payload.DOB));
                    receiveNews("true");
                    personalQuestion(payload.CustomField1Value);
                    personalQuestionAnswer(payload.CustomField2Value);
                    locale("en_AU");
                    customerCardNumber{
                        name("GiftCard");
                        number(payload.CardNumber);
                    }
                }
            }
    return xmlWriter.toString();
}

String FormatDate(def birthday){
    def dob = birthday.toString().split('/');
    String result = dob[2] + "-" + dob[1] + "-" + dob[0];
    return result;
}

String ValueMapping(def SourceValue,def testFlag = null){
    if(testFlag != true) {
        final SOURCE_AGENCY = "POS";
        final SOURCE_IDENTIFIER = "pos:gk:gender";
        final TARGET_AGENCY = "GK";
        final TARGET_IDENTIFIER = "pos:gk:gender";

        def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
        def value = valueMapApi.getMappedValue(SOURCE_AGENCY, SOURCE_IDENTIFIER, SourceValue.toString(), TARGET_AGENCY, TARGET_IDENTIFIER);
        return value;
    }else{
        return "MAN";
    }
}