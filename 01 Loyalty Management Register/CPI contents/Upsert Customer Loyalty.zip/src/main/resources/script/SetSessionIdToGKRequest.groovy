package au.net.api.loyalty

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
/* ************************************************************************
    Program     : SetSessionIdToGKRequest.groovy
    Create Date : Apr-24-2020
    Author      : Stephen Xue
    Parameters  :
        message --> message reference from framework;
        testFlag--> true for test mode; default for production code mode;
    Function    :
        1. Get session id from property
        2. insert the session id into the request to GK
    Source: XML
    Target: XML
 *************************************************************************/

Message processData(Message message, def testFlag = null) {
    def body = message.getBody(java.lang.String) as String;
    //def body = message.getBody() as String;
    def sourceRequest = new XmlSlurper(false,false).parseText(body);

    def sessionID = message.getProperties().get("SessionID");
    sourceRequest.sessionId = sessionID;
    def result = XmlUtil.serialize(sourceRequest);
    message.setBody(result);
    return message;
}