package au.net.api.loyalty

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import org.apache.camel.RollbackExchangeException

/* ************************************************************************
    Program     : POS_UpdateMemberRequest_to_S4_BusinessPartnerERPCreateRequestConfirmation.groovy
    Create Date : Apr-06-2020
    Author      : Stephen Xue
    Parameters  :
        message --> message reference from framework;
        testFlag--> true for test mode; default for production code mode;
    Function    :
        1. Parse request message coming from POS for Member update/register
        2. Convert it into BusinessPartnerERPCreateRequestConfirmation to S4
    Source: XML
    Target: XML
 *************************************************************************/

Message processData(Message message, def testFlag = null) {
    def targetRequest;

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.setStringProperty("Logging01", "Start getting message body.");

    // Parse request type  
    def body = message.getBody(java.lang.String) as String;
    //def body = message.getBody() as String;
    def sourceRequest = new XmlSlurper(false,false).parseText(body);
    if(testFlag == null) {
        messageLog.setStringProperty("Logging02", "Start mapping step.");
    }
    targetRequest = Mapping(sourceRequest,testFlag);
    if(testFlag == null) {
        messageLog.setStringProperty("Logging03", "Finish mapping step.");
    }

    message.setHeader("Content-Type","Application/xml");
    message.setBody(targetRequest);
    return message;
}

String Mapping(def payload,def testFlag = null){
    final CUSTOMER_TYPE     = "ZCON";
    final CATEGORY_PERSON   = "1";
    final LANGUAGE_ENGLISH  = "EN";
    final COUNTRY_AU        = "AU";
    final ROLE              = "ZFLCU1";
    final CATEGORY          = "FLCU01";
    final ADDRESS_CODE      = "XXDEFAULT";
    final BOOLEAN_TRUE      = "true";
    final BOOLEAN_FALSE     = "false";

    def xmlWriter = new StringWriter();
    def xmlMarkup = new MarkupBuilder(xmlWriter);

    xmlMarkup
            .'ns1:BusinessPartnerERPCreateRequestMessage_sync'('xmlns:ns1': 'http://sap.com/xi/APPL/Global2'){
                MessageHeader{
                    CreationDateTime(GetSystemDateTime("yyyy-MM-dd'T'HH:mm:ssZ"));
                };
                BusinessPartner{
                    NumberRangeIntervalBusinessPartnerGroupCode(CUSTOMER_TYPE);
                    CategoryCode(CATEGORY_PERSON);
                    Common{
                        VerbalCommunicationLanguageCode(LANGUAGE_ENGLISH);
                        Person{
                            Name{
                                FormOfAddressCode(ValueMapping(payload.Title,"S4","title",testFlag));
                                GivenName(payload.FirstName);
                                FamilyName(payload.LastName);
                            }
                            GenderCode(ValueMapping(payload.Gender,"S4","gender",testFlag));
                            BirthDate(FormatDate(payload.DOB));
                            NonVerbalCommunicationLanguageCode(LANGUAGE_ENGLISH);
                            NationalityCountryCode(COUNTRY_AU);
                            OriginCountryCode(COUNTRY_AU);
                        }
                    };
                    Role{
                        RoleCode(ROLE);
                        PartyBusinessCharacterCode(CATEGORY);
                    };
                    AddressInformation{
                        AddressUsage{
                            AddressUsageCode(ADDRESS_CODE);
                            ValidityPeriod{
                                StartDate(GetSystemDateTime("yyyy-MM-dd"));
                                EndDate("9999-12-31");
                            };
                            DefaultIndicator(BOOLEAN_TRUE);
                        };
                        Address{
                            PostalAddress{
                                CountryCode(COUNTRY_AU);
                                CityName(payload.Suburb);
                                DistrictName(payload.Suburb);
                                PostalCode(payload.PostCode);
                                StreetName(payload.AddressLine2);
                                HouseID(payload.AddressLine1);
                                AdditionalHouseID("");
                                BuildingID("");
                                RoomID("");
                                FloorID("");
                                TimeZoneCode("AUSACT");
                            };
                            CommunicationPreference{
                                CorrespondenceLanguageCode(LANGUAGE_ENGLISH);
                            };
                            Telephone{
                                Number{
                                    SubscriberID(payload.Mobile.toString().trim());
                                    ExtensionID();
                                    CountryCode(COUNTRY_AU);
                                };
                                UsageDeniedIndicator(BOOLEAN_FALSE);
                                MobilePhoneNumberIndicator(BOOLEAN_TRUE);
                            }
                            Email{
                                URI(payload.EmailAddress);
                                UsageDeniedIndicator(BOOLEAN_FALSE);
                            }
                        }
                    }
                }
            }
    return xmlWriter.toString();
};

String GetSystemDateTime(def format){
    def now = new Date();
    return now.format(format);
}

String FormatDate(def birthday){
    def dob = birthday.toString().split('/');
    String result = dob[2] + "-" + dob[1] + "-" + dob[0];
    return result;
}

String ValueMapping(def SourceValue, def TargetSystem, def VM_type, def testFlag = null){
    if(testFlag != true) {
        final SOURCE_AGENCY     = "POS";
        final SOURCE_IDENTIFIER = TARGET_IDENTIFIER = "pos:" + TargetSystem.toLowerCase() + ":" + VM_type;
        final TARGET_AGENCY     = TargetSystem.toUpperCase();

        def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
        def value = valueMapApi.getMappedValue(SOURCE_AGENCY, SOURCE_IDENTIFIER, String.valueOf(SourceValue), TARGET_AGENCY, TARGET_IDENTIFIER);
        return value;
    }else{
        return "dummy_" + VM_type;
    }
}

