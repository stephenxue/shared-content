package au.net.api.loyalty

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi


/* ************************************************************************
    Program     : POS_UpdateMemberRequest_to_S4_BusinessPartnerERPUpdateRequestConfirmation.groovy
    Create Date : Apr-06-2020
    Author      : Stephen Xue
    Parameters  :
        message --> message reference from framework;
        testFlag--> true for test mode; default for production code mode;
    Function    :
        1. Parse request message coming from POS for Member update/register
        2. Convert it into BusinessPartnerERPUpdateRequestConfirmation to S4
    Source: XML
    Target: XML
 *************************************************************************/

Message processData(Message message, def testFlag = null) {
    def targetRequest;

    def messageLog = messageLogFactory.getMessageLog(message);
    messageLog.setStringProperty("Logging", "Start getting message body.");
    
    // Parse Message Properties
    def InternalID      = message.getProperties().get("InternalID");
    // Parse request body
    def body = message.getBody(java.lang.String) as String;
    //def body = message.getBody() as String;
    def sourceRequest = new XmlSlurper(false,false).parseText(body);
    if(testFlag == null) {
        messageLog.setStringProperty("Logging", "Start mapping step.");
    }
    targetRequest = Mapping(sourceRequest,InternalID,testFlag);
    if(testFlag == null) {
        messageLog.setStringProperty("Logging", "Finish mapping step.");
    }

    message.setHeader("Content-Type","Application/xml");
    message.setBody(targetRequest);
    return message;
}

String Mapping(def payload, String internalID, def testFlag = null){
    final END_DATE          = "9999-12-31";

    def xmlWriter = new StringWriter();
    def xmlMarkup = new MarkupBuilder(xmlWriter);

    xmlMarkup
            .'ns1:BusinessPartnerERPUpdateRequestMessage_sync'('xmlns:ns1': 'http://sap.com/xi/APPL/Global2'){
                MessageHeader{
                    CreationDateTime(GetSystemDateTime("yyyy-MM-dd'T'HH:mm:ssZ"));
                };
                BusinessPartner("actionCode": "02"){
                    InternalID(internalID);
                    Common("actionCode": "02"){
                        if(payload.Title||payload.FirstName||payload.LastName||payload.Gender||payload.DOB){
                            ValidityPeriod{
                                StartDate(GetSystemDateTime("yyyy-MM-dd"));
                                EndDate(END_DATE);
                            }
                            Person{
                                if(payload.Title||payload.FirstName||payload.LastName){
                                    Name{
                                        if(payload.Title){
                                            FormOfAddressCode(ValueMapping(payload.Title,"title",testFlag));
                                        };
                                        if(payload.FirstName){
                                            GivenName(payload.FirstName);
                                        };
                                        if(payload.LastName){
                                            FamilyName(payload.LastName);
                                        };
                                    }
                                };
                                if(payload.Gender){
                                    GenderCode(ValueMapping(payload.Gender,"gender",testFlag));
                                };
                                if(payload.DOB){
                                    BirthDate(FormatDate(payload.DOB));
                                }
                            }
                        }
                    };
                    if(payload.Suburb||payload.Suburb||payload.PostCode||payload.AddressLine1||payload.AddressLine2||payload.Mobile||payload.EmailAddress){
                        AddressInformation("actionCode": "02"){
                            Address{
                                if(payload.Suburb||payload.PostCode||payload.AddressLine1||payload.AddressLine2){
                                    PostalAddress("actionCode": "02"){
                                        if(payload.Suburb){
                                            CityName(payload.Suburb);
                                            DistrictName(payload.Suburb);
                                        };
                                        if(payload.PostCode){
                                            PostalCode(payload.PostCode);
                                        };
                                        if(payload.AddressLine1){
                                            HouseID(payload.AddressLine1);
                                        };
                                        if(payload.AddressLine2){
                                            StreetName(payload.AddressLine2);
                                        };
                                    }
                                };
                                if(payload.Mobile){
                                    Telephone{
                                        Number{
                                            SubscriberID(payload.Mobile.toString().trim());
                                        }
                                    }
                                };
                                if(payload.EmailAddress){
                                    Email{
                                        URI(payload.EmailAddress);
                                    }
                                }
                            };
                        }
                    }
                }
            }
    return xmlWriter.toString();
}

String FormatDate(def birthday){
    def dob = birthday.toString().split('/');
    String result = dob[2] + "-" + dob[1] + "-" + dob[0];
    return result;
}

String GetSystemDateTime(def format){
    def now = new Date();
    String result = now.format(format);
    return result;
}


String ValueMapping(def SourceValue, def VM_type, def testFlag = null){
    if(testFlag != true) {
        final SOURCE_AGENCY     = "POS";
        final SOURCE_IDENTIFIER = "pos:s4:" + VM_type;
        final TARGET_AGENCY     = "S4";
        final TARGET_IDENTIFIER = "pos:s4:" + VM_type;

        def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null);
        def value = valueMapApi.getMappedValue(SOURCE_AGENCY, SOURCE_IDENTIFIER, SourceValue.toString(), TARGET_AGENCY, TARGET_IDENTIFIER);
        return value;
    }else{
        return "dummy_" + VM_type;
    }
}