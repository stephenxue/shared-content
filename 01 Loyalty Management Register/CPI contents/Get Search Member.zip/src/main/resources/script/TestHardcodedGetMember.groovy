package au.net.api.loyalty
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message, def testFlag = null) {
    def text = GetTestPayload();
    message.setHeader("Content-Type","Application/xml");
    message.setBody(new String(text).trim());
    return message;
}

def GetTestPayload(){
    def text = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Response>
    <RequestType>GetMember</RequestType>
    <sysUserName>username</sysUserName>
    <sysTranId>unqiueTransactionId</sysTranId>
    <CardNumber>12345678901234567</CardNumber>
    <ResponseCode>0</ResponseCode>
    <ResponseMessage>Ok</ResponseMessage>
    <MemberTierId>10</MemberTierId>
    <MemberTierDescription>Gold Member</MemberTierDescription>
    <MemberStatus>10</MemberStatus>
    <MemberStatusMessage>
        Incomplete: Please complete customer details.
    </MemberStatusMessage>
    <Title>Mr</Title>
    <FirstName>John</FirstName>
    <LastName>Smith</LastName>
    <AddressLine1>12</AddressLine1>
    <AddressLine2>Test Road</AddressLine2>
    <Suburb>Testville</Suburb>
    <State>VIC</State>
    <PostCode>3000</PostCode>
    <Country>AU</Country>
    <EmailAddress>test@test.com.au</EmailAddress>
    <Mobile>0422 445 456</Mobile>
    <DOB>21/10/1976</DOB>
    <DOBStatus>10</DOBStatus>
    <Gender>M</Gender>
    <CustomField1Name></CustomField1Name>
    <CustomField1Value></CustomField1Value>
    <CustomField2Name></CustomField2Name>
    <CustomField2Value></CustomField2Value>
    <CustomField3Name></CustomField3Name>
    <CustomField3Value></CustomField3Value>
    <MailingAddressStatus>10</MailingAddressStatus>
    <MailingOptOutStatus>True</MailingOptOutStatus>
    <EmailAddressStatus>10</EmailAddressStatus>
    <EmailAddressOptOutStatus>False</EmailAddressOptOutStatus>
    <MobileStatus>10</MobileStatus>
    <EmailAddressOptInDate>2013-12-01 15:54:48</EmailAddressOptInDate>
    <EmailAddressOptOutDate></EmailAddressOptOutDate>
    <MailingAddressOptInDate>2013-12-01 15:54:48</MailingAddressOptInDate>
    <MailingAddressOptOutDate>2013-12-03 09:23:23</MailingAddressOptOutDate>
    <CurrentPointsBalance>245</CurrentPointsBalance>
    <CurrentTierSpend>245</CurrentTierSpend>
    <TierSpendToUpgrade>245</TierSpendToUpgrade>
    <TierSpendToMaintain>245</TierSpendToMaintain>
    <TierReviewDate>2019-10-10</TierReviewDate>

    <PointsBalanceUpdated>2013-12-03 09:23:23</PointsBalanceUpdated>
    <MarketingContentBlock>
        Buy One Get One Free\\nPurchase Any Item Worth $20 or more\\nand receive another item of equal or lesser value FREE!!
    </MarketingContentBlock>
    <LastUpdated>2014-08-21 15:24:09</LastUpdated>
    <CurrentBalance>30</CurrentBalance>
    <AvailableBalance>21.50</AvailableBalance>
    <Balances>
        <Balance>
            <CardNumber>5029041234567881</CardNumber>
            <PIN>1234</PIN>
            <Name>Birthday Reward</Name>
            <OfferId>BR</OfferId>
            <OpeningBalance>10</OpeningBalance>
            <AvailableBalance>10</AvailableBalance>
            <ExpiryDate>2016-11-30</ExpiryDate>
            <TenderCode>BR</TenderCode>
        </Balance>
        <Balance>
            <CardNumber>5029041234567880</CardNumber>
            <PIN>1234</PIN>
            <Name>Quarter Reward 2016 March</Name>
            <OfferId>QR2016Q1</OfferId>
            <OpeningBalance>10</OpeningBalance>
            <AvailableBalance>1.50</AvailableBalance>
            <ExpiryDate>2016-12-31</ExpiryDate>
            <TenderCode>QR</TenderCode>
        </Balance>
        <Balance>
            <CardNumber>5029041234567881</CardNumber>
            <PIN>1234</PIN>
            <Name>Quarter Reward 2016 July</Name>
            <OfferId>QR2016Q2</OfferId>
            <OpeningBalance>10</OpeningBalance>
            <AvailableBalance>10</AvailableBalance>
            <ExpiryDate>2017-07-01</ExpiryDate>
            <TenderCode>QR</TenderCode>
        </Balance>
    </Balances>
    <Offers>
        <Offer>
            <CardNumber>5029041234567890</CardNumber>
            <PIN>1234</PIN>
            <Name>Gift Box Quarter 1</Name>
            <OfferId>GB2016Q1</OfferId>
            <ExpiryDate>2016-12-31</ExpiryDate>
            <OfferType>10</OfferType>
            <TenderCode>GB</TenderCode>
        </Offer>
        <Offer>
            <CardNumber>5029041234567891</CardNumber>
            <PIN>1234</PIN>
            <Name>Beauty Consult</Name>
            <OfferId>BC2016Q1</OfferId>
            <ExpiryDate>2016-12-31</ExpiryDate>
            <OfferType>10</OfferType>
            <TenderCode>BC</TenderCode>
        </Offer>
        <Offer>
            <CardNumber>5029041234567892</CardNumber>
            <PIN>1234</PIN>
            <Name>Beauty Consult</Name>
            <OfferId>BC2016Q2</OfferId>
            <ExpiryDate>2017-12-31</ExpiryDate>
            <OfferType>10</OfferType>
            <TenderCode>BC</TenderCode>
        </Offer>
    </Offers>
    <Segments>
        <Segment>
            <SegmentId>123456</SegmentId>
        </Segment>
        <Segment>
            <SegmentId>123456</SegmentId>
        </Segment>
    </Segments>
</Response>
               ''';
    return text;
}