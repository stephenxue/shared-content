package au.net.api.loyalty

import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.nrc.NumberRangeConfigurationService
import groovy.json.*;
/* ************************************************************************
    Program     : ReserveIDListFromNumberRange.groovy
    Create Date : Mar-10-2020
    Author      : Stephen Xue
    Function    :
       the request is in form of:
       {
            "number":<100>
       }
       the program will reserve 100 member IDs in the number range and send
       the list of reserved member IDs as response to API consumer
 *************************************************************************/
class MemberID{
    def memberid = "";
}

Message processData(Message message, def testFlag = null) {
    // Get property 'NumberRangeName'
    def numberRange = message.getProperties().get("NumberRangeName");
    // Get Header property 'ProcessType'
    def processType = message.getHeaders().get("ProcessType");
    if(processType == "getIDlist") {
        def body = message.getBody(java.lang.String) as String;
        def jsonSlurper = new JsonSlurper();
        def jsonBody = jsonSlurper.parseText(body);
        def response = new ArrayList<MemberID>();
        for(int i = 0;i<jsonBody.number;i++){
            def item = new MemberID();
            if(testFlag != true) {
                item.memberid = getNextNumber(numberRange);
            }else{
                item.memberid = i.toString();
            }
            response << item;
        }
        def result = JsonOutput.toJson(response);
        message.setBody(result);
    }
    return message;
}

def String getNextNumber(String NR_NAME) {
    def NRCS = ITApiFactory.getApi(NumberRangeConfigurationService.class, null);
    def nextValue = NRCS.getNextValuefromNumberRange(NR_NAME,null);
    return nextValue;
}
