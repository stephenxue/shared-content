var schema  = JSON.parse(Base64.decode(context.getVariable("JsonSchema")));
var request = JSON.parse(context.getVariable("request.content"));
if(tv4.validate(request, schema)){
    context.setVariable("validRequest" ,true);
}else{
    context.setVariable("validRequest" ,false);
    context.setVariable("tv4ErrorCode" ,tv4.error.code);
    context.setVariable("tv4ErrorDataPath" ,tv4.error.dataPath);
    context.setVariable("tv4ErrorSchemaPath" ,tv4.error.schemaPath);
    context.setVariable("ERRORMSG" ,tv4.error.message);
}