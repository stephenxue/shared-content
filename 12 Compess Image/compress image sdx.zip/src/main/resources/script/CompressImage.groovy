import com.sap.gateway.ip.core.customdev.util.Message
import groovy.transform.Field
import javax.imageio.stream.ImageOutputStream
import static java.awt.RenderingHints.*
import java.awt.image.BufferedImage
import javax.imageio.ImageIO
/* ************************************************************************
    Program     : CompressImage.groovy
    Create Date : Oct-26-2021
    Author      : Stephen Xue
    Parameters  :
        message --> message reference from framework;
        testFlag--> true for test mode; default for production code mode;
    Function    :
        1. Compress Image
    Source: BINARY
    Target: BINARY
 *************************************************************************/

@Field String SHIP_TO_PARTY = 'WE';

Message processData(Message message, def testFlag = null) {
    def body = message.getBody(byte[]);
    //def body = message.getBody() as String;
    InputStream is = new ByteArrayInputStream(body);
    def img       = ImageIO.read( is );
    def type      = message.getHeaders().get('Content-Type').toString().split("/")?.getAt(1);
    def scale     = message.getProperties().get('scale') as float;
    int newWidth  = img.width * scale
    int newHeight = img.height * scale
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    new BufferedImage( newWidth, newHeight, img.type ).with { i ->
        createGraphics().with {
            setRenderingHint( KEY_INTERPOLATION, VALUE_INTERPOLATION_BICUBIC )
            drawImage( img, 0, 0, newWidth, newHeight, null )
            dispose()
        }
        ImageIO.write( i, type, outputStream);
    }
    message.setBody(outputStream);
    return message
}